/*************************
	Brandon Huzil
	200379909
	CS 409
*************************/

#include <cassert>
#include <cmath>
#include <string>
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <time.h>
#include <sstream>
#include <chrono>
#include <vector>


#include "GetGlut.h"
#include "Sleep.h"
#include "CoordinateSystem.h"
#include "PerlinNoiseField.h"
#include "Asteroid.h"
#include "Spaceship.h"
#include "Crystal.h"
#include "Drone.h"

#include "ObjLibrary/ObjModel.h"
#include "ObjLibrary/DisplayList.h"
#include "ObjLibrary/SpriteFont.h"

using namespace std;
using namespace chrono;
using namespace ObjLibrary;


int crystalIDCounter = 0;
const int NUM_OF_ASTEROIDS = 50;
const int MAX_NUM_OF_CRYSTALS = 100;
const int STARTING_NUM_OF_DRONES = 5;
int numOfDrones;
int collectedCrystals;
int numOfCrystals;
bool gameOn = true;
// bool to decide whether to run determineDronesToChaseCrytsals(), is set to true by this func and false by crystal pulse (potentially) and when a cystal is collected and when a drone is destroyed
bool validPursueBehaviour = true;

ObjModel disk;
SpriteFont font;
ObjModel baseCrystal;

Asteroid* asteroids[NUM_OF_ASTEROIDS];
Crystal* crystals[MAX_NUM_OF_CRYSTALS];
Spaceship spaceship;
Drone* drones[STARTING_NUM_OF_DRONES];
Entity* droneCrystalPairs[2][STARTING_NUM_OF_DRONES];

const unsigned int KEY_UP_ARROW = 256;
const unsigned int KEY_DOWN_ARROW = 257;
const unsigned int KEY_LEFT_ARROW = 258;
const unsigned int KEY_RIGHT_ARROW = 259;
const unsigned int KEY_END = 260;
const unsigned int KEY_COUNT = 261;
bool key_pressed[KEY_COUNT];

int window_width = 1024;
int window_height = 768;

unsigned int update_count = 0;
const int UPDATES_PER_SECOND = 60;
const double SECONDS_PER_UPDATES = 1.0 / UPDATES_PER_SECOND;
const microseconds MICROSECONDS_PER_UPDATE(1000000 / UPDATES_PER_SECOND);
const unsigned int MAXIMUM_UPDATES_PER_FRAME = 10;
const unsigned int FAST_UPDATES_FACTOR = 10;
const double SIMULATE_SLOW_SECONDS = 0.05;

system_clock::time_point next_update_time; // Check
const unsigned int SMOOTH_RATE_COUNT = MAXIMUM_UPDATES_PER_FRAME * 2 + 2;
system_clock::time_point old_frame_times[SMOOTH_RATE_COUNT];
system_clock::time_point old_update_times[SMOOTH_RATE_COUNT];
unsigned int next_old_update_index = 0;
unsigned int next_old_frame_index = 0;

microseconds delta_time = MICROSECONDS_PER_UPDATE;
bool hasUpdated = false;

void init ();
void initDisplay ();
void keyboard (unsigned char key, int x, int y);
void keyboardUp(unsigned char key, int x, int y);
void special(int special_key, int x, int y);
void specialUp(int special_key, int x, int y);
void update ();
void updateInput();
void updateCollisions();
void updateEntities();
void reshape (int w, int h);
void display ();
void PerlinText3D(float amplitude);
void drawText();
void placeInitialCollidingAsteroids(ObjModel model);
bool areColliding(Entity *e1, Entity *e2);
bool areAsteroidsColliding(Asteroid * a1, Asteroid * a2);
bool areAsteroidsAndEntityColliding(Asteroid* a, Entity* e);
void testAndExecuteAsteroidAndDroneCollisions();
void testAndExecuteAsteroidAndCrystalCollisions();
void crystalPulse();
// function assigns a crystal to each drone to pursue
void determineDronesToChaseCrytsals(int min);
void nullifyDroneCrystalPairs();




int main (int argc, char* argv[])
{
	srand(time(0));
	glutInitWindowSize(window_width, window_height);
	glutInitWindowPosition(0, 0);

	// init gl and give the call back functions
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
	glutCreateWindow("CS 409 Game Brandon Huzil");
	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyboardUp);
	glutSpecialFunc(special);
	glutSpecialUpFunc(specialUp);
	glutIdleFunc(update);
	glutReshapeFunc(reshape);
	glutDisplayFunc(display);


	PerlinText3D(0.25);

	init();

	glutMainLoop();  // contains an infinite loop, so it never returns
	return 1;
}

void init ()
{
	initDisplay();
	ObjModel baseSpaceship;
	baseSpaceship.load("Sagittarius.obj");
	spaceship.setModel(baseSpaceship);

	// create all the asteroids
	ObjModel baseAsteroid;
	baseAsteroid.load("AsteroidA.obj");

	// for assignment 5 I am not going to place 2 asteroids in a special case to collide imidiatly
	for (int x = 0; x < NUM_OF_ASTEROIDS/* - 2*/; x++)
		asteroids[x] = new Asteroid(baseAsteroid);
	//placeInitialCollidingAsteroids(baseAsteroid);

	baseCrystal.load("Crystal.obj");

	//create drones
	ObjModel baseDrone; baseDrone.load("Grapple.obj");
	Vector3 droneFormationDisplacement = Vector3(0, 5, 0);
	Vector3 spaceshipPosition = spaceship.getLocalCoordinateSystem().getPosition();
	Vector3 playerVelocity = spaceship.getVelocity();
	for (int i = 0; i < STARTING_NUM_OF_DRONES; i++)
	{
		drones[i] = new Drone(spaceshipPosition + droneFormationDisplacement, playerVelocity, (i/5.0)*(2.0*3.1415), baseDrone, i, & spaceship, asteroids, NUM_OF_ASTEROIDS);
		droneFormationDisplacement.rotateX((1.0 /5.0) * (2 * 3.1415)); // initially place drones in a 5 pointed circle around the player in the xy plane
	}
	numOfDrones = STARTING_NUM_OF_DRONES;

	for (int i = 0; i < STARTING_NUM_OF_DRONES; i++)
	{
		droneCrystalPairs[0][i] = drones[i];
		droneCrystalPairs[1][i] = NULL;
	}


	numOfCrystals = 0;
	collectedCrystals = 0;

	
	font.load("Font.bmp");
	disk.load("Disk.obj");
}

void initDisplay ()
{
	glClearColor(0.5, 0.5, 0.5, 0.0);
	glColor3f(0.0, 0.0, 0.0);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);

	glutPostRedisplay();
}

void keyboard (unsigned char key, int x, int y)
{
	switch (key)
	{
		case 27: // on [ESC]
			//delete asteroids;
			//delete crystals;
			exit(0); // normal exit
			break;
		case 't':  // t corosponds to showing the axes
		case 'T':
		{
			bool show = asteroids[0]->getShowAxesAndMarkers();
			if (show)
				show = false;
			else
				show = true;

			for (int x = 0; x < NUM_OF_ASTEROIDS; x++)
				asteroids[x]->setShowAxesAndMarkers(show);

			for (int x = 0; x < numOfDrones; x++)
				drones[x]->setShowPositions(show);
			break;
		}
	}

		

	if (key >= 'a' && key <= 'z')
		key = key - 'a' + 'A';

	if (key == 'K' || key == '0')
		crystalPulse();// break off crystals

	key_pressed[key] = true;
}

void keyboardUp(unsigned char key, int x, int y)
{
	if (key >= 'a' && key <= 'z')
		key = key - 'a' + 'A';

	key_pressed[key] = false;
}

void special(int special_key, int x, int y)
{
	switch (special_key)
	{
	case GLUT_KEY_UP:
		key_pressed[KEY_UP_ARROW] = true;
		break;
	case GLUT_KEY_DOWN:
		key_pressed[KEY_DOWN_ARROW] = true;
		break;
	case GLUT_KEY_LEFT:
		key_pressed[KEY_LEFT_ARROW] = true;
		break;
	case GLUT_KEY_RIGHT:
		key_pressed[KEY_RIGHT_ARROW] = true;
		break;
	}
}

void specialUp(int special_key, int x, int y)
{
	switch (special_key)
	{
	case GLUT_KEY_UP:
		key_pressed[KEY_UP_ARROW] = false;
		break;
	case GLUT_KEY_DOWN:
		key_pressed[KEY_DOWN_ARROW] = false;
		break;
	case GLUT_KEY_LEFT:
		key_pressed[KEY_LEFT_ARROW] = false;
		break;
	case GLUT_KEY_RIGHT:
		key_pressed[KEY_RIGHT_ARROW] = false;
		break;
	}
}

void update()
{
	if (!hasUpdated)
	{
		hasUpdated = true;

		system_clock::time_point start_time = system_clock::now();
		next_update_time = start_time;

		for (unsigned int i = 1; i < SMOOTH_RATE_COUNT; i++)
		{
			unsigned int steps_back = SMOOTH_RATE_COUNT - i;
			old_update_times[i] = start_time - MICROSECONDS_PER_UPDATE * steps_back;
			old_frame_times[i] = start_time - MICROSECONDS_PER_UPDATE * steps_back;
		}
	}
	
	system_clock::time_point current_time = system_clock::now();
	for (unsigned int i = 0; i < MAXIMUM_UPDATES_PER_FRAME && next_update_time < current_time; i++)
	{
		++update_count;

		delta_time = MICROSECONDS_PER_UPDATE;

		if (key_pressed['G'])
			delta_time *= FAST_UPDATES_FACTOR;

		if (delta_time.count() > 0.0)
		{
			updateInput();
			if (gameOn)
			{
				updateCollisions();
				updateEntities();
			}

			old_update_times[next_old_update_index % SMOOTH_RATE_COUNT] = current_time;
			next_old_update_index++;

			if (key_pressed['U'])
				sleep(SIMULATE_SLOW_SECONDS);
		}

		next_update_time += MICROSECONDS_PER_UPDATE;
		current_time = system_clock::now();

	}

	if (current_time < next_update_time)
	{
		system_clock::duration sleep_time = next_update_time - current_time;
		sleep(duration<double>(sleep_time).count());
	}

	update_count = 0;
	glutPostRedisplay();
}

void updateInput()
{
	if (key_pressed[KEY_LEFT_ARROW])
		spaceship.rotateAroundUp(true, delta_time);
	if (key_pressed[KEY_RIGHT_ARROW])
		spaceship.rotateAroundUp(false, delta_time);
	if (key_pressed[KEY_UP_ARROW])
		spaceship.rotateAroundRight(true, delta_time);
	if (key_pressed[KEY_DOWN_ARROW])
		spaceship.rotateAroundRight(false, delta_time);

	if (gameOn)
	{
		if (key_pressed['W'])
			spaceship.moveUp(true, delta_time);
		if (key_pressed['S'])
			spaceship.moveUp(false, delta_time);
		if (key_pressed['A'])
			spaceship.moveRight(false, delta_time);
		if (key_pressed['D'])
			spaceship.moveRight(true, delta_time);
		if (key_pressed['B'])
			spaceship.applyBrake(delta_time);

		if (key_pressed[':'] || key_pressed[';'])
			spaceship.moveForward(true, false, delta_time);
		if (key_pressed['/'])
			spaceship.moveForward(false, false, delta_time);
		if (key_pressed[' '])
			spaceship.moveForward(true, true, delta_time);
		if (key_pressed['<'] || key_pressed[','])
			spaceship.rotateAroundForward(false, delta_time);
		if (key_pressed['>'] || key_pressed['.'])
			spaceship.rotateAroundForward(true, delta_time);


	}
}

void updateCollisions()
{
	//test for player collision with asteroids
	for (int i = 0; i < NUM_OF_ASTEROIDS && gameOn; i++)
		if (areAsteroidsAndEntityColliding(asteroids[i], &spaceship))
			gameOn = false;

	//test for player and drone collision with crystals
	for (int i = 0; i < numOfCrystals && gameOn; i++)
	{
		bool crystalCollided = false;
		if (areColliding(&spaceship, crystals[i]))
		{
			collectedCrystals++;
			delete crystals[i];
			for (int j = i + 1; j < numOfCrystals; j++)
				crystals[j - 1] = crystals[j];
			crystals[numOfCrystals - 1] = NULL;
			numOfCrystals--;
			if (numOfCrystals == 0)
				nullifyDroneCrystalPairs();
			else
				validPursueBehaviour = false;
			crystalCollided = true;
			// this must be done so displaying pursue positions does not cause a crash if we collected a drones target crystal
			for (int j = 0; j < numOfDrones; j++)
				drones[j]->nullifyTargetCrystal();
		}

		// drones
		for (int j = 0; !crystalCollided && j < numOfDrones; j++)
		{

			if (areColliding(drones[j], crystals[i]))
			{
				collectedCrystals++;

				delete crystals[i];
				for (int j = i + 1; j < numOfCrystals; j++)
					crystals[j - 1] = crystals[j];
				crystals[numOfCrystals - 1] = NULL;
				numOfCrystals--;
				if (numOfCrystals == 0)
					nullifyDroneCrystalPairs();
				else
					validPursueBehaviour = false;
				drones[j]->nullifyTargetCrystal();
				crystalCollided = true;
			}

		}
	}

	//test for asteroid to drone collisions
	testAndExecuteAsteroidAndDroneCollisions();

	//test for asteroid to asteroid collision
	testAndExecuteAsteroidAndCrystalCollisions();
}

void updateEntities()
{
	//update asteroids
	for (int x = 0; x < NUM_OF_ASTEROIDS; x++)
		asteroids[x]->update(delta_time);

	//update spaceship
	spaceship.update(delta_time);

	// update drones
	int min = 0;
	if (numOfCrystals > 0)
	{
		// determine the min of numOfCrystals and numOfDrones
		if (numOfCrystals < numOfDrones)
			min = numOfCrystals;
		else
			min = numOfDrones;
	}

	if (!validPursueBehaviour && min > 0)
	{
		determineDronesToChaseCrytsals(min);
	}

	for (int x = 0; x < numOfDrones; x++)
	{
		drones[x]->update(droneCrystalPairs[1][x], delta_time);
	}


	//update crystals
	for (int x = 0; x < numOfCrystals; x++)
		crystals[x]->update(delta_time);
}

// for when the screen size is changed
void reshape (int w, int h)
{
	glViewport (0, 0, w, h);

	window_width = w;
	window_height = h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLdouble)w / (GLdouble)h, 0.1, 100000.0);// was 1000 for the last parameter
	glMatrixMode(GL_MODELVIEW);

	glutPostRedisplay();
}

void display ()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// clear the screen - any drawing before here will not display at all

	glLoadIdentity();


	//spaceship
	spaceship.draw(delta_time);

	// Drones
	for (int x = 0; x < numOfDrones; x++)
		drones[x]->draw(delta_time);

	// draw a black sphere for the event horizon of the black hole
	glColor3d(0.0, 0.0, 0.0);
	glPushMatrix();
		glutSolidSphere(50.0,30, 30);
		glTranslated(0.0, 0.0, 0.0);
	glPopMatrix();

	// Asteroids
	for (int x = 0; x < NUM_OF_ASTEROIDS; x++)
		asteroids[x]->draw(delta_time, spaceship.getLocalCoordinateSystem().getPosition());

	// crystals
	for (int x = 0; x < numOfCrystals; x++)
		crystals[x]->draw(delta_time);

	// Accreation Disk, it must be drawn last
	glPushMatrix();
		glTranslated(0.0, 0.0, 0.0);
		glScaled(5000.0, 1.0, 5000.0);
		disk.draw();
	glPopMatrix();

	drawText();

	// send the current image to the screen - any drawing after here will not display
	glutSwapBuffers();

}






// A demonstration of the use of perlin noise
void PerlinText3D(float amplitude)
{
	PerlinNoiseField perlinNoise(6.0, amplitude);
	char darkChars[9] = { ' ', '.', '-', '=', 'o', 'O', 'H', 'M', '@' };
	float noiseVals[20][20][20];
	float smallest;
	float largest = smallest = perlinNoise.perlinNoise(0, 0, 0);
	float segmentSize;
	int tesssssss = 555;


	// store 30 x 30 x 30 perlin noise vals and determine the smallest and largest of them
	for (int z = 0; z < 20; z++) 
		for (int y = 0; y < 20; y++)
			for (int x = 0; x < 20; x++)
			{
				noiseVals[x][y][z] = perlinNoise.perlinNoise(x, y, z);
				if (noiseVals[x][y][z] > largest)
					largest = noiseVals[x][y][z];
				else if (noiseVals[x][y][z] < smallest)
					smallest = noiseVals[x][y][z];
			}

	// find 1/9th of the difference between smallest and largest
	segmentSize = (largest - smallest) / 9.0 + 0.0001; // +0.0001 ensures the largest value does not go outside for the dark char bounds

	// determine which of the 9 equal segments between smallest and largest that each noise val lies within
	for (int y = 0; y < 20; y++)
	{
		for (int x = 0; x < 20; x++)
		{
			float temp = smallest;
			int segment = 0;
			while (temp < noiseVals[x][y][0])
			{
				temp += segmentSize;
				segment++;
			}
			if (segment != 0)
				cout << darkChars[segment - 1];
			else
				cout << darkChars[0];
		}
		cout << endl;
	}
	cout << endl << endl;

	for (int z = 0; z < 20; z++)
	{
		for (int x = 0; x < 20; x++)
		{
			float temp = smallest;
			int segment = 0;
			while (temp < noiseVals[x][0][z])
			{
				temp += segmentSize;
				segment++;
			}
			if (segment != 0)
				cout << darkChars[segment - 1];
			else
				cout << darkChars[0];
		}
		cout << endl;
	}
	cout << endl << endl;

	for (int z = 0; z < 20; z++)
	{
		for (int y = 0; y < 20; y++)
		{
			float temp = smallest;
			int segment = 0;
			while (temp < noiseVals[0][y][z])
			{
				temp += segmentSize;
				segment++;
			}
			if (segment != 0)
				cout << darkChars[segment - 1];
			else
				cout << darkChars[0];
		}
		cout << endl;
	}
	cout << endl << endl;
}

void drawText()
{
	SpriteFont::setUp2dView(window_width, window_height);

	system_clock::time_point current_time = system_clock::now();

	if (!gameOn)
	{
		stringstream gameOverss;
		gameOverss << "GAME OVER";
		font.draw(gameOverss.str(), window_width / 2.0, window_height / 2.0);
	}


	// Display frame rate
	unsigned int oldest_frame_index = (next_old_frame_index + 1) % SMOOTH_RATE_COUNT;
	duration<float> total_frame_duration = current_time - old_frame_times[oldest_frame_index];
	float average_frame_duration = total_frame_duration.count() / (SMOOTH_RATE_COUNT - 1);
	float average_frame_rate = 1.0f / average_frame_duration;

	stringstream smoothed_frame_rate_ss;
	smoothed_frame_rate_ss << "Frame rate:\t" << setprecision(3) << average_frame_rate;
	font.draw(smoothed_frame_rate_ss.str(), 16, 16);

	// update frame rate values
	old_frame_times[next_old_frame_index % SMOOTH_RATE_COUNT] = current_time;
	next_old_frame_index++;


	// display update rate
	unsigned int oldest_update_index = (next_old_update_index + 1) % SMOOTH_RATE_COUNT;
	duration<float> total_update_duration = current_time - old_update_times[oldest_update_index];
	float average_update_duration = total_update_duration.count() / (SMOOTH_RATE_COUNT - 1);
	float average_update_rate = 1.0f / average_update_duration;

	stringstream smoothed_update_rate_ss;
	smoothed_update_rate_ss << "Update rate:\t" << setprecision(3) << average_update_rate;
	font.draw(smoothed_update_rate_ss.str(), 16, 40);




	stringstream floatingCrystalNum_ss;
	floatingCrystalNum_ss << "Drifting Crystals: " << numOfCrystals;
	font.draw(floatingCrystalNum_ss.str(), 16, 80);

	stringstream collectedCrystalNum_ss;
	collectedCrystalNum_ss << "Collected Crystals: " << collectedCrystals;
	font.draw(collectedCrystalNum_ss.str(), 16, 112);

	stringstream numberOfDrones_ss;
	numberOfDrones_ss << "Drones: " << numOfDrones;
	font.draw(numberOfDrones_ss.str(), 16, 144);

	SpriteFont::unsetUp2dView();
}

void placeInitialCollidingAsteroids(ObjModel model)
{
	Vector3 playerPosition = spaceship.getLocalCoordinateSystem().getPosition();

	asteroids[NUM_OF_ASTEROIDS - 2] = new Asteroid(model, playerPosition + Vector3(700, 0, 400), Vector3(0, 0, -1), 200.0, 160.0);
	asteroids[NUM_OF_ASTEROIDS - 1] = new Asteroid(model, playerPosition + Vector3(700, 0, -400), Vector3(0, 0, 1), 150.0, 110.0);
}

bool areColliding(Entity *e1, Entity *e2)
{
	// determine if they occupy the same space
	

	return (e1->getLocalCoordinateSystem().getPosition().isDistanceLessThan(e2->getLocalCoordinateSystem().getPosition(), e1->getRadius() + e2->getRadius()));
}

bool areAsteroidsColliding(Asteroid * a1, Asteroid * a2)
{
	Vector3 displacement1To2 = a2->getLocalCoordinateSystem().getPosition() - a1->getLocalCoordinateSystem().getPosition();
	float distance1To2 = displacement1To2.getNorm();
	Vector3 direction1To2 = displacement1To2.getNormalized();

	if (a1->getRadius() + a2->getRadius() > distance1To2 && a1->calculateSurfaceDistance(direction1To2) + a2->calculateSurfaceDistance(-direction1To2) > distance1To2)
		return true;
	else
		return false;

}

bool areAsteroidsAndEntityColliding(Asteroid* a, Entity* e)
{
	Vector3 displacementaToe = e->getLocalCoordinateSystem().getPosition() - a->getLocalCoordinateSystem().getPosition();
	float distanceaToe = displacementaToe.getNorm();
	Vector3 directionaToe = displacementaToe.getNormalized();


	float radiusSum = a->getRadius() + e->getRadius();
	if (radiusSum > distanceaToe)
	{
		//cout << "radiusSum: " << radiusSum << " is bigger then distance to: " << distanceaToe << endl;

		float surfaceDistance = a->calculateSurfaceDistance(directionaToe);
		float surfaceDistancePlusRadius = surfaceDistance + e->getRadius();
		if (surfaceDistancePlusRadius > distanceaToe)
		{
			return true;
		}
	}
	return false;
}

void testAndExecuteAsteroidAndDroneCollisions()
{
	for (int i = 0; i < NUM_OF_ASTEROIDS; i++)
		for (int j = 0; j < numOfDrones; j++)
		{
			if (areAsteroidsAndEntityColliding(asteroids[i], drones[j]))
			{
				asteroids[i]->elasticCollision(drones[j]);

				delete drones[j];
				for (int k = j + 1; k < numOfDrones; k++)
					drones[k - 1] = drones[k];
				drones[numOfDrones - 1] = NULL;
				numOfDrones--;
				validPursueBehaviour = false;
			}
		}

}

void testAndExecuteAsteroidAndCrystalCollisions()
{
	for (int i = 0; i < NUM_OF_ASTEROIDS - 1; i++)
	{
		for (int k = i + 1; k < NUM_OF_ASTEROIDS; k++)
			if (areAsteroidsColliding(asteroids[i], asteroids[k]))
			//if (areColliding(asteroids[i], asteroids[k]))
				asteroids[i]->elasticCollision(asteroids[k]);

		// test asteroid i against all the crystals
		for (int j = 0; j < numOfCrystals; j++)
			if (areAsteroidsAndEntityColliding(asteroids[i], crystals[j]))// && asteroids[i]->getVelocity().dotProduct(crystals[j]->getVelocity()) < 0)
				asteroids[i]->elasticCollision(crystals[j]);
	}
}

void crystalPulse()
{
	if (numOfCrystals < MAX_NUM_OF_CRYSTALS) // if we can add crystals into the game
	{
		Vector3 spaceshipPosition = spaceship.getLocalCoordinateSystem().getPosition();
		Vector3 displacement;
		Vector3 crystalSpawnPoint;
		for (int i = 0; i < NUM_OF_ASTEROIDS; i++) // for each asteroid that still has crystals
		{
			if (asteroids[i]->getHasCrystals())
			{
				displacement = spaceshipPosition - asteroids[i]->getLocalCoordinateSystem().getPosition();
				//														I thought 200 was too close so i extended it to 300
				if (displacement.getNorm() <= asteroids[i]->calculateSurfaceDistance(displacement/displacement.getNorm()) + 300) // if this particular asteroid is close enaugh to break off crystals, 
				{
					int counter = 0;
					while (numOfCrystals < MAX_NUM_OF_CRYSTALS && counter++ < 10) // break of 10 crystals or less then 10 so to not exceed MAX_NUM_OF_CRYSTALS
					{
						crystalSpawnPoint = asteroids[i]->breakOffCrystals(spaceshipPosition, displacement);
						Vector3 positionOffset = Vector3::getRandomUnitVector() * ((float)(rand() % 5)); // not asked for in assignment but create some variability in crystal positions
						// initial velocity must result in crystals that travel with the asteroid but also slightly in the direction in which they broke off relative to the asteroids center
						// to do thhis i will take the velocity of the asteroid and add the unit vector that points from the asteroids center to the position where crystals are being broken
						//Vector3 initialVelocity = asteroids[i]->getVelocity() + (displacement / displacement.getNorm()) * 30.5 + Vector3::getRandomUnitVector() * 15.0;
						crystals[numOfCrystals++] = new Crystal(crystalIDCounter++, baseCrystal, crystalSpawnPoint + positionOffset, asteroids[i]->getVelocity(), displacement);
						validPursueBehaviour = false;
					}
				}
			}
		}
	}
}

// function assigns a crystal to each drone to pursue
void determineDronesToChaseCrytsals(int min)
{
	if (drones[1] == NULL)
		int test = 0;

	nullifyDroneCrystalPairs();
	// create a 2d array to hold the distances from each crystal to each drone
	float distances[MAX_NUM_OF_CRYSTALS][STARTING_NUM_OF_DRONES];
	for (int i = 0; i < numOfCrystals; i++)
		for (int j = 0; j < numOfDrones; j++)
			distances[i][j] = crystals[i]->getLocalCoordinateSystem().getPosition().getDistance(drones[j]->getLocalCoordinateSystem().getPosition());

	// create bool arrays to determine whether a row or coloumn in distances is active
	bool activeRows[MAX_NUM_OF_CRYSTALS];
	for (int x = 0; x < MAX_NUM_OF_CRYSTALS; x++)
	{
		if (x < numOfCrystals)
			activeRows[x] = true;
		else
			activeRows[x] = false;
	}
	bool activeCols[STARTING_NUM_OF_DRONES];
	for (int x = 0; x < STARTING_NUM_OF_DRONES; x++)
	{
		if (x < numOfDrones)
			activeCols[x] = true;
		else
			activeCols[x] = false;
	}

	// loop min times and determine the smallest distance, assign that drone to pursue that crystal then ignore that row and coloumn going forward
	// ie a greedy algorithm to pursue based off of smallest distances
	float smallest;
	int crystalNum;
	int droneNum;
	int counter = 0;
	Entity* crystal;
	Entity* drone;

	for (int x = 0; x < min; x++)
	{
		bool firstAvailibleDistance = true;

		for (int i = 0; i < numOfCrystals; i++)
			for (int j = 0; j < numOfDrones; j++)
				if (activeRows[i] && activeCols[j])
					if (firstAvailibleDistance || distances[i][j] < smallest)
					{
						smallest = distances[i][j];
						crystalNum = i;
						droneNum = j;
						firstAvailibleDistance = false;
					}
		// we now know smallest
		// delete that row and coloumn 
		activeRows[crystalNum] = false;
		activeCols[droneNum] = false;
		

		// now place the corosponding drone and crystal into droneCrystalPairs
		//droneCrystalPairs[0][counter] = drones[droneNum];
		droneCrystalPairs[1][droneNum] = crystals[crystalNum];
	}

	validPursueBehaviour = true;
}

void nullifyDroneCrystalPairs()
{
	for (int i = 0; i < STARTING_NUM_OF_DRONES; i++)
	{
		droneCrystalPairs[1][i] = NULL;
	}
}
